### Overview
The Elastos brand is more than just an idea on paper; it is the embodiment of our company, encompassing all of the experiences and expectations that people associate with us. To protect the integrity of the visual expression of the Elastos brand, it is critical to follow the logo guidelines outlined.

This includes all of the logo assets you need—to create a consistent tone, look, and feel for Elastos’ communication materials. We invite you to absorb this information and reference it often to become an informed keeper of the brand.

Complete Brand Style Guide available soon.
